
Individual-Lab 2: Plagiarism detector.

This program does:

1. compare two essays, essay-1.txt and essay-2.txt

2. find the common words, counts and lists them

3. searches for a specific word, returns true if present in both essays

4. calculates the percentage of plagiarism using the formula 
plagiarism%= (Number of common words (intersection)/ Total unique words (union)) * 100

